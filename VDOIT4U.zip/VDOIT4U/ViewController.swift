//
//  ViewController.swift
//  VDOIT4U
//
//  Created by Guri Bambhrah on 13/06/16.
//  Copyright © 2016 VDoIt4U. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {
    @IBOutlet var username: UITextField!
    @IBOutlet var password: UITextField!
    var resultString: NSString = "Failure"
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    @IBAction func buttonPress(sender: AnyObject) {
        
        if (self.resultString == "success" && username.text != nil && password.text != nil){
            print("Success Printed")
            let secondViewControllerObj = self.storyboard?.instantiateViewControllerWithIdentifier("SecondViewController") as? SecondViewController
            self.navigationController?.pushViewController(secondViewControllerObj!, animated: true)
            username.text = ""
            password.text = ""
            resultString = ""
        }
        else
        {
            print("no navigation")
        }
    }
    
    func textFieldDidEndEditing(textField: UITextField) {
        if textField.tag == 1
        {let request = NSMutableURLRequest(URL: NSURL(string: "http://127.0.0.1/php_data/app_login2.php")!)
            request.HTTPMethod = "POST"
            let postString = "username=\(username.text!)&password=\(password.text!)"
            request.HTTPBody = postString.dataUsingEncoding(NSUTF8StringEncoding)
            
            let task = NSURLSession.sharedSession().dataTaskWithRequest(request) {
                data, response, error in
                
                if error != nil {
                    print("error=\(error)")
                    return
                }
                print("response = \(response)")
                
                let responseString = NSString(data: data!, encoding: NSUTF8StringEncoding)
                print("responseString = \(responseString)")
                self.resultString = responseString!
                return
            }
            task.resume()}
    }
    
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true;
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

}

